package TestCaseLeads;

import java.io.IOException;
import java.util.Map;

import com.eva.vtiger.Marketing.Leads.MarkCreateLeadsPage;
import com.eva.vtiger.Marketing.Leads.MarketingLeadsPage;
import com.eva.vtiger.MyHomePage.Home.HomePage;
import com.eva.vtiger.login.LoginVtiger;
import GenericMethodsFolder.WebUtil;
import ReadExcelData_Utility.ExcelUtility;

public class CreateLeads {
	static WebUtil gn = new WebUtil("TC001");
	static Map<String, String> rowData;

	public void registerLeads() throws IOException, InterruptedException {
		ExcelUtility.getAllData("ExcelFile\\Test Data.xlsx", "VerifyLeads");
		int mapCount = ExcelUtility.listAllData.size();
		gn.openBrowser("chrome");
		gn.navigateUrl("http://localhost:8888");
		LoginVtiger logP = new LoginVtiger(gn);
		for (int i = 0; i < mapCount; i++) {
			rowData = ExcelUtility.listAllData.get(i);
			HomePage homeObj  = logP.validLogin(rowData);
			MarketingLeadsPage lp = homeObj.gotoLeads();
			MarkCreateLeadsPage mCLP = lp.clickCreateLeadsButton();
			mCLP.basicInformation(rowData).saveButton();
			String scenarioType = rowData.get("ScenarioType");
			String expectedTextPopUp = rowData.get("ExpErrorMsg");
			if (scenarioType.contentEquals("invailid")) {
				gn.validatePopUpText(expectedTextPopUp);
				gn.acceptAlert(expectedTextPopUp);
				lp.signOut();
			} else {

			}
		}
		gn.getFlush();
	}

}
