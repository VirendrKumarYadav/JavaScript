package TestCaseLeads;

import java.io.IOException;

public class Runner {

	public static void main(String[] arg) throws IOException, InterruptedException  {
		CreateLeads cl=new CreateLeads();
		cl.registerLeads();
	}

}
