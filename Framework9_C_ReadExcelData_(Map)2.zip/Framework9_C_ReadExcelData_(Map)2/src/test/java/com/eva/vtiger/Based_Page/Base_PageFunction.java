package com.eva.vtiger.Based_Page;

import java.io.IOException;
import org.openqa.selenium.support.PageFactory;
import com.eva.vtiger.Based_OR.Base_OR;
import GenericMethodsFolder.WebUtil;

public class Base_PageFunction extends Base_OR {

	private WebUtil gn;

	public Base_PageFunction(WebUtil gn) {
		this.gn = gn;
		PageFactory.initElements(gn.getDriver(), this);
	}

	public void signOut() throws IOException {
		gn.click(signOut, "SignOut");
	}

	public void saveButton() throws IOException {
		gn.click(saveBt, "saveButton");
	}

	/**
	 * Send data in Search Box
	 * 
	 * @param dataValue
	 * @throws IOException
	 */
	public void inputValueInSerchBox(String dataValue) throws IOException {
		gn.inputTextValue(dataValue, searchBox, "SearchBox");
	}

	/**
	 * Select Drop Down In Search Drop Down
	 * 
	 * @param selectDD
	 * @throws IOException
	 */
	public void selectValueInDropDown(String selectDD) throws IOException {
		gn.selectByValue(searchDropDown, "SearchDD", selectDD);
	}

	/**
	 * Search Button
	 * 
	 * @throws IOException
	 */
	public void clickOnSearchBt() throws IOException {
		gn.click(searchBt, "searchBt");
	}

	public void searchData(String interDataValue, String selectDD) throws IOException {
		inputValueInSerchBox(interDataValue);
		selectValueInDropDown(selectDD);
		clickOnSearchBt();
	}
}
