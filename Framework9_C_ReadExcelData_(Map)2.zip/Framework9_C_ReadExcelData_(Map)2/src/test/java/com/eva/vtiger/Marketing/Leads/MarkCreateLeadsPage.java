package com.eva.vtiger.Marketing.Leads;

import java.io.IOException;
import java.util.Map;
import com.eva.vtiger.OR_Marketing.Leads.MarkCreateLeadsPageOR;
import GenericMethodsFolder.WebUtil;

public class MarkCreateLeadsPage extends MarkCreateLeadsPageOR {

	private WebUtil gn;

	public MarkCreateLeadsPage(WebUtil gn) {
		super(gn);
		this.gn = gn;
	}

	/**
	 * @param gn
	 * @throws IOException
	 */
	public MarkCreateLeadsPage basicInformation(Map<String, String> mapObj) throws IOException {
		gn.inputTextValue(mapObj.get("FirstName"), firstName, "First Name");
		gn.inputTextValue(mapObj.get("LastName"), lastName, "Last Name");
		gn.inputTextValue(mapObj.get("Company_Name"), companyName, "Company Name");
		gn.inputTextValue(mapObj.get("mobile"), mobileNo, "mobile box");
		return this;
	}

	/**
	 * @param gn
	 * @throws IOException
	 */
	public void saveButton() throws IOException {
		gn.click(saveBt, "saveButton");
	}

	/**
	 * @param gn
	 * @throws IOException
	 */
	public void cancelButton() throws IOException {
		gn.click(cancelBt, "cancelButton");
	}

	/**
	 * @param gn
	 * @throws IOException
	 */
	public void moreInformation() throws IOException {
		// gn.click("//b[text()='More Information ']", "xpath", "more Information");
	}

	/**
	 * @param gn
	 * @throws IOException
	 */
	public void clickbasicInformation() throws IOException {
		// gn.click("//b[text()='More Information ']", "xpath", "basic information");
	}
}
