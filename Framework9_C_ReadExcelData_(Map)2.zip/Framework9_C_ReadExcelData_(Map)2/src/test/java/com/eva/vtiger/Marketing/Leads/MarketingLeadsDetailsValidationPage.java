package com.eva.vtiger.Marketing.Leads;

import java.io.IOException;

import com.eva.vtiger.OR_Marketing.Leads.MarketingLeadsDetailsValidationPageOR;

import GenericMethodsFolder.WebUtil;

public class MarketingLeadsDetailsValidationPage extends MarketingLeadsDetailsValidationPageOR {

	private WebUtil gn;

	public MarketingLeadsDetailsValidationPage(WebUtil gn) {
		super(gn);
		this.gn = gn;
	}

	public void validateText() throws IOException {
		gn.validateText(firstName, "Ram", "firstName");
	}
}
