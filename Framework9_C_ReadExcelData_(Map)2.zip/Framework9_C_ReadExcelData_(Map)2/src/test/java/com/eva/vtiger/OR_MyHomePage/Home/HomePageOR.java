package com.eva.vtiger.OR_MyHomePage.Home;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import GenericMethodsFolder.WebUtil;

public class HomePageOR {

	@FindBy(linkText = "Marketing")
	protected WebElement marketingModule;
	@FindBy(linkText = "Accounts")
	protected WebElement accountSubM;
	@FindBy(linkText = "Leads")
	protected WebElement leadsSubM;
	@FindBy(linkText = "Documents")
	protected WebElement documentsSubM;
	
	public HomePageOR(WebUtil gn) {
		PageFactory.initElements(gn.getDriver(), this);
	}
}
