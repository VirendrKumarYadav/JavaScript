package testcaseScript;

import java.awt.AWTException;
import java.io.IOException;

public class Runner {

	public static void main(String[] arg) throws IOException, AWTException, InterruptedException {
		RegistrationLeads rL = new RegistrationLeads();
		rL.createLeads();
//		rL.validateAccountName();
		
//		TestScriptOfVerify ts=new TestScriptOfVerify();
//		ts.loginVerify();
	}

}
