package testcaseScript;

import java.io.IOException;
import java.util.Map;

import com.eva.vtiger.MyHomePage.Home.HomePage;
import com.eva.vtiger.login.LoginVtiger;
import GenericMethodsFolder.WebUtil;
import ReadExcelData_Utility.ExcelUtility;

public class TestScriptOfVerify {
	static WebUtil gn = new WebUtil("TC001");
	static Map<String, String> rowDM;

	public void loginVerify() throws IOException {
		ExcelUtility.getAllData("ExcelFile\\Test Data.xlsx", "VerifyLeads");
		int mapCount = ExcelUtility.listAllData.size();
		gn.openBrowser("chrome");
		gn.navigateUrl("http://localhost:8888");
		for (int i = 0; i < mapCount; i++) {
			rowDM = ExcelUtility.listAllData.get(i);
			LoginVtiger logP = new LoginVtiger(gn);
			HomePage homeObj = logP.validLogin(rowDM);
			String expectedErrorMsg = rowDM.get("ErrorMsg");
			String scenario = rowDM.get("ScenarioType");
			if (scenario.equalsIgnoreCase("invailid")) {
				logP.validateErrorMsgSt(expectedErrorMsg, "ErrorMsgSt");
			} else {
				homeObj.verifyVisibleMarketing("Marketing");
			}
		}
		gn.getFlush();
	}

}
