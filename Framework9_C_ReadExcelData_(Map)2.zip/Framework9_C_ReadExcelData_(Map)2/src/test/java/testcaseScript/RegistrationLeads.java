package testcaseScript;

import java.io.IOException;
import java.util.Map;
import com.eva.vtiger.Marketing.Accounts.MarketingAccountsPage;
import com.eva.vtiger.Marketing.Leads.MarkCreateLeadsPage;
import com.eva.vtiger.Marketing.Leads.MarketingLeadsPage;
import com.eva.vtiger.MyHomePage.Home.HomePage;
import com.eva.vtiger.login.LoginVtiger;
import GenericMethodsFolder.WebUtil;
import ReadExcelData_Utility.ExcelUtility;

public class RegistrationLeads {
	static WebUtil gn = new WebUtil("TC001");
	static Map<String, String> map;

	public HomePage loginVtiger() throws IOException, InterruptedException {
		HomePage hp = null;
		ExcelUtility.getAllData("ExcelFile\\Test Data.xlsx", "Test Data");
		int mapCount = ExcelUtility.listAllData.size();
		for (int i = 0; i <= mapCount - 1; i++) {
			map = ExcelUtility.listAllData.get(i);
			gn.openBrowser("chrome");
			gn.navigateUrl("http://localhost:8888");
			LoginVtiger logP = new LoginVtiger(gn);
			hp = logP.validLogin(map);
			if (gn.getDriver().getTitle().contains("admin - My Home Page - Home - vtiger CRM 5")) {
			} else {
				gn.close("");
			}
		}
		return hp;
	}

	// create Leads \\
	public void createLeads() throws IOException, InterruptedException {
		HomePage hp = loginVtiger();
		MarketingLeadsPage lp = hp.gotoLeads();
		MarkCreateLeadsPage cl = lp.clickCreateLeadsButton();
		cl.basicInformation(map).saveButton();
		gn.getFlush();
	}

	// Validate Account Name \\
	public void validateAccountName() throws IOException, InterruptedException {
		map = ExcelUtility.getData("ExcelFile\\Test Data.xlsx", "Test Data", 6);
		String browserName = map.get("BrowserName");
		gn.openBrowser(browserName);
		gn.navigateUrl("http://localhost:8888");
		LoginVtiger logP = new LoginVtiger(gn);
		HomePage hp = logP.validLogin(map);
		MarketingAccountsPage AccPage = hp.gotoAccounts();
		// AccPage.createAccountButton().basicInformation().saveButton();;
		AccPage.searchData(map.get("FirstName"), "Account Name");
		gn.getFlush();
	}
}
